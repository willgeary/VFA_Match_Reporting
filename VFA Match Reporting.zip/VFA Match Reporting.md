
# VFA Match Activity Reporting

### Load and Clean Data

Load raw data from csv into dataframe


```python
import os
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from IPython.display import display, HTML
%matplotlib inline
```


```python
os.chdir("C:/Users/Will/Dropbox/Documents/VFA/Match Reporting")
df = pd.read_csv("Activity_Raw.csv")
```


```python
df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>name.1</th>
      <th>fromRole</th>
      <th>creator</th>
      <th>status</th>
      <th>Status description</th>
      <th>firstName</th>
      <th>lastName</th>
      <th>email</th>
      <th>message</th>
      <th>created_at</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Philadelphia</td>
      <td>Compass</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Richard</td>
      <td>Oneslager</td>
      <td>richard.d.oneslager@gmail.com</td>
      <td>NaN</td>
      <td>3/23/2016 21:30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Providence</td>
      <td>Focal Upright</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Richard</td>
      <td>Oneslager</td>
      <td>richard.d.oneslager@gmail.com</td>
      <td>NaN</td>
      <td>3/23/2016 21:27</td>
    </tr>
    <tr>
      <th>2</th>
      <td>San Antonio</td>
      <td>ScaleWorks</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Claudia</td>
      <td>Wynn</td>
      <td>cwynn@seas.upenn.edu</td>
      <td>NaN</td>
      <td>3/23/2016 21:26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Birmingham</td>
      <td>TheraNest</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Claudia</td>
      <td>Wynn</td>
      <td>cwynn@seas.upenn.edu</td>
      <td>NaN</td>
      <td>3/23/2016 21:26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Baltimore</td>
      <td>Leverege</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Claudia</td>
      <td>Wynn</td>
      <td>cwynn@seas.upenn.edu</td>
      <td>NaN</td>
      <td>3/23/2016 21:26</td>
    </tr>
  </tbody>
</table>
</div>



Clean data frame


```python
df = df.rename(columns={'name' : 'city', 'name.1' : 'company'}) # Rename columns
```


```python
df = df.applymap(str)
```


```python
df['created_at'] = pd.to_datetime(df['created_at']) # Change created_at column to datetime
```


```python
df.dtypes
```




    city                          object
    company                       object
    fromRole                      object
    creator                       object
    status                        object
    Status description            object
    firstName                     object
    lastName                      object
    email                         object
    message                       object
    created_at            datetime64[ns]
    dtype: object




```python
df['fullName'] = df['firstName'] +" " + df['lastName'] # Create fullName column
```


```python
df['relationship'] = df['fullName'] + " / " + df['company'] # Create relationship column
```

Determine whether each relationship is initiated by the Fellow or Hiring Manager


```python
initiated_by = []
def initiated_by_calc():
    relationships = list(df['relationship'])
    for relationship in relationships:
        rec = df.loc[df['relationship'] == relationship]
        first = rec['created_at'].min()
        ifirst = int(np.where(rec['created_at']==first)[0])
        initiator = list(rec['creator'])[ifirst]
        initiated_by.append(initiator)
        
initiated_by_calc()
df['initiated_by'] = initiated_by # initiated_by column indicates if a relationship is initiated by Fellow or Hiring Manager.
```

Determine which rows are 'initiations' and which are 'responses' as to remove duplicates:


```python
df['row_type'] = np.where(df['creator'] == df['initiated_by'], 'Initiation', 'Response')
```

Filter dataframe to include only 'Initiation' rows (removing duplicates):


```python
df = df[df.row_type == 'Initiation'] # Now data frame includes only 'Initiation' rows and no duplicates
```


```python
df.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>company</th>
      <th>fromRole</th>
      <th>creator</th>
      <th>status</th>
      <th>Status description</th>
      <th>firstName</th>
      <th>lastName</th>
      <th>email</th>
      <th>message</th>
      <th>created_at</th>
      <th>fullName</th>
      <th>relationship</th>
      <th>initiated_by</th>
      <th>row_type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Philadelphia</td>
      <td>Compass</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Richard</td>
      <td>Oneslager</td>
      <td>richard.d.oneslager@gmail.com</td>
      <td>nan</td>
      <td>2016-03-23 21:30:00</td>
      <td>Richard Oneslager</td>
      <td>Richard Oneslager / Compass</td>
      <td>Fellow</td>
      <td>Initiation</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Providence</td>
      <td>Focal Upright</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Richard</td>
      <td>Oneslager</td>
      <td>richard.d.oneslager@gmail.com</td>
      <td>nan</td>
      <td>2016-03-23 21:27:00</td>
      <td>Richard Oneslager</td>
      <td>Richard Oneslager / Focal Upright</td>
      <td>Fellow</td>
      <td>Initiation</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Baltimore</td>
      <td>Leverege</td>
      <td>2</td>
      <td>Hiring Manager</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Patrick</td>
      <td>Duffy</td>
      <td>duffyp4@xavier.edu</td>
      <td>nan</td>
      <td>2016-03-23 21:20:00</td>
      <td>Patrick Duffy</td>
      <td>Patrick Duffy / Leverege</td>
      <td>Hiring Manager</td>
      <td>Initiation</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Philadelphia</td>
      <td>Tassl</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Jessica</td>
      <td>Hirsch</td>
      <td>jmh3jb@virginia.edu</td>
      <td>nan</td>
      <td>2016-03-23 21:19:00</td>
      <td>Jessica Hirsch</td>
      <td>Jessica Hirsch / Tassl</td>
      <td>Fellow</td>
      <td>Initiation</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Baltimore</td>
      <td>ClassTracks</td>
      <td>3</td>
      <td>Fellow</td>
      <td>18</td>
      <td>Introduced By Message</td>
      <td>Jessica</td>
      <td>Hirsch</td>
      <td>jmh3jb@virginia.edu</td>
      <td>nan</td>
      <td>2016-03-23 21:13:00</td>
      <td>Jessica Hirsch</td>
      <td>Jessica Hirsch / ClassTracks</td>
      <td>Fellow</td>
      <td>Initiation</td>
    </tr>
  </tbody>
</table>
</div>




```python
fellow_initiated = df.loc[(df.initiated_by == 'Fellow')] # Data frame for fellow-initations
company_initiated = df.loc[(df.initiated_by == 'Hiring Manager')] # Data frame for company-initiations
```


```python
cities = sorted(set(df['city']))
```

## Fellow-Initiated Connection Requests


```python
cities_by_fellow_interest = fellow_initiated['city'].value_counts().reset_index().sort('index').set_index('index')
cities_by_fellow_interest = cities_by_fellow_interest.rename(columns={0 : 'Fellow Connection Requests'}) # Rename columns
cities_by_fellow_interest.index.names = ['City'] # Rename index
fellow_interest = cities_by_fellow_interest.plot(kind='bar', color = sns.color_palette("hls", len(cities)),
                              legend=False, title='Fellow-Initiated Connection Requests', ylim=[0,70])
```


![png](output_23_0.png)


## Company-Initiated Connection Requests


```python
cities_by_company_interest = company_initiated['city'].value_counts().reset_index().sort('index').set_index('index')
cities_by_company_interest.rename(columns={0:'Company Connection Requests'}, inplace=True)
cities_by_company_interest.index.names = ['City']

# Add cities which have zero company-initiated requests
for city in cities:
    if city not in cities_by_company_interest.index:
        cities_by_company_interest.loc[city] = 0

cities_by_company_interest.sort_index(inplace=True)
company_interest = cities_by_company_interest.plot(kind='bar', color = sns.color_palette("hls", len(cities)),
                               legend=False, title='Company-Initiated Connection Requests', ylim=[0,70])
```


![png](output_25_0.png)


## Most Active Companies


```python
companies = set(df['company']) # list of unique companies
```


```python
companies_by_activity = pd.DataFrame(company_initiated['company'].value_counts())
companies_by_activity.index.names = ['Most Active Companies:']
companies_by_activity.rename(columns = {0:'Outgoing Connection Requests'}, inplace=True)
```


```python
company_city = []
def find_city():
    for company in companies_by_activity.index:
        city = list(df[df['company'] == company]['city'])[0]
        company_city.append(city)

find_city()
companies_by_activity['City'] = company_city
cols = ['City', 'Outgoing Connection Requests']
companies_by_activity = companies_by_activity.ix[:, cols]
```


```python
companies_by_activity.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Outgoing Connection Requests</th>
    </tr>
    <tr>
      <th>Most Active Companies:</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Leverege</th>
      <td>Baltimore</td>
      <td>32</td>
    </tr>
    <tr>
      <th>Advanced Polymer Monitoring Technologies, Inc.</th>
      <td>New Orleans</td>
      <td>26</td>
    </tr>
    <tr>
      <th>R-Squared Macro</th>
      <td>Birmingham</td>
      <td>21</td>
    </tr>
    <tr>
      <th>Fleetio</th>
      <td>Birmingham</td>
      <td>17</td>
    </tr>
    <tr>
      <th>TheraNest</th>
      <td>Birmingham</td>
      <td>16</td>
    </tr>
  </tbody>
</table>
</div>



## Most Popular Companies


```python
companies_by_popularity = pd.DataFrame(fellow_initiated['company'].value_counts())
companies_by_popularity.index.names = ['Most Popular Companies:']
companies_by_popularity.rename(columns = {0:'Incoming Connection Requests'}, inplace=True)
```


```python
company_city = []
def find_city():
    for company in companies_by_popularity.index:
        city = list(df[df['company'] == company]['city'])[0]
        company_city.append(city)

find_city()
companies_by_popularity['City'] = company_city
cols = ['City', 'Incoming Connection Requests']
companies_by_popularity = companies_by_popularity.ix[:, cols]
```


```python
companies_by_popularity.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Incoming Connection Requests</th>
    </tr>
    <tr>
      <th>Most Popular Companies:</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Banza</th>
      <td>Detroit</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Nexosis</th>
      <td>Columbus</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Compass</th>
      <td>Philadelphia</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Message Agency</th>
      <td>Philadelphia</td>
      <td>5</td>
    </tr>
    <tr>
      <th>BoxCast</th>
      <td>Cleveland</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>



## Most Active Fellows


```python
fellows = set(df['fullName']) # list of unique Fellows
```


```python
fellows_by_activity = pd.DataFrame(fellow_initiated['fullName'].value_counts())
fellows_by_activity.index.names = ['Most Active Fellows:']
fellows_by_activity.rename(columns = {0:'Outgoing Connection Requests'}, inplace=True)
```


```python
fellows_by_activity.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Outgoing Connection Requests</th>
    </tr>
    <tr>
      <th>Most Active Fellows:</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Kelly Yuen</th>
      <td>19</td>
    </tr>
    <tr>
      <th>Marisa Bruno</th>
      <td>11</td>
    </tr>
    <tr>
      <th>Sarah Bender</th>
      <td>7</td>
    </tr>
    <tr>
      <th>Jordan Star</th>
      <td>7</td>
    </tr>
    <tr>
      <th>Cate Stanton</th>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



## Most Popular Fellows


```python
fellows_by_popularity = pd.DataFrame(company_initiated['fullName'].value_counts())
fellows_by_popularity.index.names = ['Most Popular Fellows:']
fellows_by_popularity.rename(columns = {0:'Incoming Connection Requests'}, inplace=True)
```


```python
fellows_by_popularity.head()
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Incoming Connection Requests</th>
    </tr>
    <tr>
      <th>Most Popular Fellows:</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Alice Rottersman</th>
      <td>9</td>
    </tr>
    <tr>
      <th>Matthew Caponigro</th>
      <td>7</td>
    </tr>
    <tr>
      <th>James Schaefer</th>
      <td>7</td>
    </tr>
    <tr>
      <th>Megan Feichtel</th>
      <td>6</td>
    </tr>
    <tr>
      <th>Kyle Wilcox</th>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
